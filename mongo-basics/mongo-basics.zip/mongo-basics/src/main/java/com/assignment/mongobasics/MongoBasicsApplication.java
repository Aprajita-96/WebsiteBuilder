package com.assignment.mongobasics;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MongoBasicsApplication {

	public static void main(String[] args) {
		SpringApplication.run(MongoBasicsApplication.class, args);
	}

}
