package com.assignment.mongobasics.service;

import com.assignment.mongobasics.model.*;
import com.assignment.mongobasics.repository.FoodDatabase;
import com.assignment.mongobasics.repository.LoginRepo;
import com.assignment.mongobasics.repository.OrderedRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class MovieService {

    private FoodDatabase foodDatabase;
    private LoginRepo loginRepo;
    private OrderedRepo orderedRepo;
    @Autowired
    public MovieService(FoodDatabase foodDatabase,LoginRepo loginRepo,OrderedRepo orderedRepo){
        this.foodDatabase=foodDatabase;
        this.loginRepo=loginRepo;
        this.orderedRepo=orderedRepo;
    }

    public List<Movie> getAllfoodItems(){
        return foodDatabase.findAll();
    }
    public List<Users> getAllUsers(){
        System.out.println(loginRepo.findAll());
        return loginRepo.findAll();
    }
    public OrderedItems saveOrder(OrderedItems orderedItems){

        return orderedRepo.save(orderedItems);
    }

}
