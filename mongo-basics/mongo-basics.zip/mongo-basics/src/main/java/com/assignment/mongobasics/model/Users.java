package com.assignment.mongobasics.model;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@Document(collection = "Login")
public class Users {
    @Id
    private String id;
    private String usetname;
    private String password;
}
