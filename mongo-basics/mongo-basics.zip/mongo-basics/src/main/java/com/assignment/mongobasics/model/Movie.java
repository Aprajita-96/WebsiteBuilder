package com.assignment.mongobasics.model;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@Document(collection = "fooditems")
public class Movie {
    @Id
    private String id;
    private int foodId;
    private String name;
    private String cuisine;
    private boolean availabilty;
    private String price;
    private String src;
}
