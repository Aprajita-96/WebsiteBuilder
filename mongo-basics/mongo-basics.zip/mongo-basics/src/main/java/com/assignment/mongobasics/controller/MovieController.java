package com.assignment.mongobasics.controller;

import com.assignment.mongobasics.model.*;
import com.assignment.mongobasics.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Objects;

@RestController
@RequestMapping("/api")
@CrossOrigin()
public class MovieController {
    private MovieService movieService;
    @Autowired
    public MovieController(MovieService movieService){
        this.movieService=movieService;
    }


    @GetMapping("")
    public ResponseEntity<List<Movie>> getAllMovies(){
        return new ResponseEntity<>(movieService.getAllfoodItems(),HttpStatus.OK);
    }
    @GetMapping("login")
    public ResponseEntity<List<Users>> getAllUsers(){
        return new ResponseEntity<>(movieService.getAllUsers(),HttpStatus.OK);
    }
    @PostMapping("save")
    public ResponseEntity<OrderedItems> getAllUsers(@RequestBody OrderedItems orderedItems){
        return new ResponseEntity<>(movieService.saveOrder(orderedItems),HttpStatus.OK);
    }
}
