package com.assignment.mongobasics.repository;

import com.assignment.mongobasics.model.OrderedItems;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface OrderedRepo extends MongoRepository<OrderedItems,String> {
}
