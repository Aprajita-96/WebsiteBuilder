package com.assignment.mongobasics.repository;

import com.assignment.mongobasics.model.Users;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface LoginRepo extends MongoRepository<Users,String> {
}
