package com.assignment.mongobasics.repository;

import com.assignment.mongobasics.model.Movie;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FoodDatabase extends MongoRepository<Movie,String> {
    //public List<Movie> findByTitleIgnoreCase(String title);
    @Query("SELECT r from Food-Items")
    public List<Movie> getAll();
}
